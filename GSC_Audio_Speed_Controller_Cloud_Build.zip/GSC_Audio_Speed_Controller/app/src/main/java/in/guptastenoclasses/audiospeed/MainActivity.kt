package in.guptastenoclasses.audiospeed

import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import java.util.Locale
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    private var player: ExoPlayer? = null
    private var audioUri: Uri? = null
    private var originalWpm = 84
    private var selectedWpm = 80
    private lateinit var originalInput: EditText
    private lateinit var selectedLabel: TextView
    private lateinit var fileLabel: TextView
    private lateinit var playButton: Button
    private lateinit var seekBar: SeekBar
    private lateinit var timeLabel: TextView
    private val handler = Handler(Looper.getMainLooper())
    private val prefs by lazy { getSharedPreferences("gsc_audio_prefs", MODE_PRIVATE) }

    private val pickAudio = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val displayName = queryDisplayName(uri)
                val safeName = displayName.replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "dictation_audio" }
                val destination = File(filesDir, safeName)
                contentResolver.openInputStream(uri)?.use { input ->
                    destination.outputStream().use { output -> input.copyTo(output) }
                } ?: throw IllegalStateException("Could not read selected audio")
                val localUri = Uri.fromFile(destination)
                audioUri = localUri
                prefs.edit().putString("audio_uri", localUri.toString()).putString("audio_name", displayName).apply()
                loadAudio(localUri)
                fileLabel.text = "Saved in app: $displayName"
            } catch (e: Exception) {
                Toast.makeText(this, "Could not import audio: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        originalWpm = prefs.getInt("original_wpm", 84)
        selectedWpm = prefs.getInt("selected_wpm", 80)
        buildScreen()
        val savedUri = prefs.getString("audio_uri", null)
        if (savedUri != null) {
            try {
                audioUri = Uri.parse(savedUri)
                loadAudio(audioUri!!)
                fileLabel.text = "Saved in app: ${prefs.getString("audio_name", "Selected audio")}" 
            } catch (_: Exception) {
                fileLabel.text = "No audio selected"
            }
        }
        updateSpeedLabel()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            setBackgroundColor(Color.rgb(250, 248, 246))
        }
        val title = TextView(this).apply {
            text = "GSC Audio Speed Controller"
            textSize = 22f; setTextColor(Color.rgb(116, 27, 53)); gravity = Gravity.CENTER
            setTypeface(null, android.graphics.Typeface.BOLD)
        }
        root.addView(title, matchWrap())
        val subtitle = TextView(this).apply {
            text = "GUPTA STENO CLASSES • ALWAR"
            textSize = 12f; setTextColor(Color.DKGRAY); gravity = Gravity.CENTER
            setPadding(0, dp(5), 0, dp(18))
        }
        root.addView(subtitle, matchWrap())

        val choose = Button(this).apply {
            text = "CHOOSE AUDIO FILE"
            setTextColor(Color.WHITE); backgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(116, 27, 53))
            setOnClickListener { pickAudio.launch(arrayOf("audio/*")) }
        }
        root.addView(choose, matchWrap())
        fileLabel = TextView(this).apply {
            text = "No audio selected"; textSize = 14f; setTextColor(Color.DKGRAY)
            setPadding(dp(4), dp(12), dp(4), dp(12))
        }
        root.addView(fileLabel, matchWrap())

        val wpmRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val wpmTitle = TextView(this).apply { text = "Original recording WPM:"; textSize = 14f; setTextColor(Color.BLACK) }
        wpmRow.addView(wpmTitle, LinearLayout.LayoutParams(0, dp(52), 1f))
        originalInput = EditText(this).apply {
            setText(originalWpm.toString()); inputType = android.text.InputType.TYPE_CLASS_NUMBER
            textSize = 18f; gravity = Gravity.CENTER; setSingleLine(true)
            setEms(4)
        }
        wpmRow.addView(originalInput, LinearLayout.LayoutParams(dp(90), dp(52)))
        val apply = Button(this).apply {
            text = "SET"; setOnClickListener { saveOriginalWpm() }
        }
        wpmRow.addView(apply)
        root.addView(wpmRow, matchWrap())

        selectedLabel = TextView(this).apply {
            textSize = 32f; setTextColor(Color.rgb(22, 125, 75)); gravity = Gravity.CENTER
            setTypeface(null, android.graphics.Typeface.BOLD); setPadding(0, dp(16), 0, dp(4))
        }
        root.addView(selectedLabel, matchWrap())
        val speedHint = TextView(this).apply {
            text = "Select playback speed"; textSize = 13f; setTextColor(Color.GRAY); gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(10))
        }
        root.addView(speedHint, matchWrap())

        val speeds = (60..160 step 5).toList()
        speeds.chunked(3).forEach { group ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            group.forEach { speed ->
                val b = Button(this).apply {
                    text = "$speed\nWPM"; textSize = 13f
                    setOnClickListener { chooseSpeed(speed) }
                    isAllCaps = false
                }
                val lp = LinearLayout.LayoutParams(0, dp(58), 1f)
                lp.setMargins(dp(3), dp(3), dp(3), dp(3))
                row.addView(b, lp)
            }
            root.addView(row, matchWrap())
        }

        playButton = Button(this).apply {
            text = "▶  PLAY"; textSize = 17f
            setOnClickListener { togglePlayback() }
        }
        root.addView(playButton, matchWrap())
        seekBar = SeekBar(this).apply {
            max = 1000
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) { if (fromUser) seekToProgress(progress) }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        root.addView(seekBar, matchWrap())
        timeLabel = TextView(this).apply { text = "00:00 / 00:00"; gravity = Gravity.CENTER; setTextColor(Color.DKGRAY) }
        root.addView(timeLabel, matchWrap())
        val note = TextView(this).apply {
            text = "Tip: Enter the original WPM once. The app calculates the required playback rate automatically."
            textSize = 12f; setTextColor(Color.GRAY); setPadding(0, dp(14), 0, 0)
        }
        root.addView(note, matchWrap())
        setContentView(root)
    }

    private fun loadAudio(uri: Uri) {
        if (player == null) {
            player = ExoPlayer.Builder(this).build().also { exo ->
                exo.addListener(object : Player.Listener {
                    override fun onIsPlayingChanged(isPlaying: Boolean) { playButton.text = if (isPlaying) "Ⅱ  PAUSE" else "▶  PLAY" }
                    override fun onPlaybackStateChanged(playbackState: Int) {
                        if (playbackState == Player.STATE_READY) updateProgress()
                        if (playbackState == Player.STATE_ENDED) playButton.text = "▶  PLAY"
                    }
                })
            }
        }
        player?.setMediaItem(MediaItem.fromUri(uri))
        player?.prepare()
        player?.playWhenReady = false
        applySpeed()
        Toast.makeText(this, "Audio loaded", Toast.LENGTH_SHORT).show()
    }

    private fun chooseSpeed(speed: Int) {
        selectedWpm = speed
        prefs.edit().putInt("selected_wpm", speed).apply()
        applySpeed()
        updateSpeedLabel()
    }

    private fun saveOriginalWpm() {
        val value = originalInput.text.toString().toIntOrNull()
        if (value == null || value <= 0) {
            originalInput.error = "Enter a valid original WPM"
            return
        }
        originalWpm = value
        prefs.edit().putInt("original_wpm", value).apply()
        applySpeed(); updateSpeedLabel()
        Toast.makeText(this, "Original WPM saved", Toast.LENGTH_SHORT).show()
    }

    private fun applySpeed() {
        if (originalWpm <= 0) return
        val rate = selectedWpm.toFloat() / originalWpm.toFloat()
        // Pitch remains at 1.0 while tempo changes.
        player?.playbackParameters = PlaybackParameters(rate, 1.0f)
    }

    private fun updateSpeedLabel() {
        val rate = if (originalWpm > 0) selectedWpm.toFloat() / originalWpm.toFloat() * 100f else 100f
        selectedLabel.text = "$selectedWpm WPM"
        if (::timeLabel.isInitialized) {
            val percent = String.format(Locale.US, "%.2f", rate)
            timeLabel.text = "Playback rate: $percent%  •  Original: $originalWpm WPM"
        }
    }

    private fun togglePlayback() {
        val exo = player
        if (exo == null || audioUri == null) {
            Toast.makeText(this, "Please choose an audio file first", Toast.LENGTH_SHORT).show(); return
        }
        if (exo.isPlaying) exo.pause() else {
            if (exo.playbackState == Player.STATE_ENDED) exo.seekTo(0)
            exo.play()
        }
        updateProgress()
    }

    private fun queryDisplayName(uri: Uri): String {
        var name = "Dictation audio"
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (index >= 0) name = cursor.getString(index) ?: name
            }
        }
        return name
    }

    private fun updateProgress() {
        val exo = player ?: return
        val duration = exo.duration.coerceAtLeast(0L)
        val position = exo.currentPosition.coerceAtLeast(0L)
        if (duration > 0) seekBar.progress = ((position.toDouble() / duration) * 1000).roundToInt()
        timeLabel.text = "${formatTime(position)} / ${formatTime(duration)}"
        if (exo.isPlaying) handler.postDelayed({ updateProgress() }, 500)
    }

    private fun seekToProgress(progress: Int) {
        val duration = player?.duration ?: return
        if (duration > 0) player?.seekTo((duration * progress / 1000).toLong())
    }

    private fun formatTime(ms: Long): String {
        val seconds = (ms / 1000).coerceAtLeast(0)
        return String.format(Locale.US, "%02d:%02d", seconds / 60, seconds % 60)
    }

    override fun onStop() {
        super.onStop()
        prefs.edit().putInt("original_wpm", originalWpm).putInt("selected_wpm", selectedWpm).apply()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        player?.release(); player = null
        super.onDestroy()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()
    private fun matchWrap() = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
}
